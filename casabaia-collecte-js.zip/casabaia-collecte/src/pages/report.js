import { state, stats, exportBackup, importBackup } from '../database/store.js';
import { pageHead, statCard, toast } from '../components/ui.js';
import { confirmDialog } from '../components/modal.js';
import { saveTextFile, shareText, toCsv } from '../services/files.js';
import { STATUS_LABELS } from '../js/config.js';

export default {
  id: 'report',
  title: 'Rapports',
  render() {
    const s = stats();
    return (
      pageHead('Synthèse', 'Rapports opérationnels', 'Exporter les données enregistrées sur cet appareil') +
      `<div class="grid">
        ${statCard('Points', s.total, 'Total')}
        ${statCard('Collectés', s.collected, 'État actuel')}
        ${statCard('Ignorés', s.skipped, 'État actuel')}
        ${statCard('Incidents', s.totalIncidents, 'Total enregistré')}
      </div>
      <section class="panel"><h2>Exporter</h2>
        <div class="actions">
          <button type="button" class="primary" id="exportJson">Exporter une sauvegarde JSON</button>
          <button type="button" class="secondary" id="exportCsv">Exporter les points CSV</button>
          <button type="button" class="secondary" id="shareReport">Partager le résumé</button>
          <label class="secondary file-btn">Importer une sauvegarde<input id="importJson" type="file" accept=".json,application/json" hidden></label>
        </div>
        <p class="muted">Conservez régulièrement une sauvegarde. Les données sont stockées localement et ne sont pas synchronisées automatiquement entre appareils.</p>
      </section>`
    );
  },
  bind(root, app) {
    const guard = (fn) => async (...args) => {
      try {
        await fn(...args);
      } catch (err) {
        if (err?.name === 'AbortError') return; // partage annulé par l'utilisateur
        console.error(err);
        toast('Action impossible : ' + (err?.message || 'erreur'), 'error');
      }
    };

    root.querySelector('#exportJson').addEventListener(
      'click',
      guard(async () => {
        const data = await exportBackup();
        await saveTextFile('casabaia-sauvegarde.json', JSON.stringify(data, null, 2), 'application/json');
        toast('Sauvegarde exportée');
      }),
    );

    root.querySelector('#exportCsv').addEventListener(
      'click',
      guard(async () => {
        const rows = [
          ['ID', 'Nom', 'Secteur', 'Adresse', 'Latitude', 'Longitude', 'Statut', 'Remplissage (%)'],
          ...state.points.map((p) => [p.id, p.name, p.neighborhood, p.address, p.lat, p.lng, STATUS_LABELS[p.status] ?? p.status, p.fillLevel]),
        ];
        await saveTextFile('casabaia-points.csv', toCsv(rows), 'text/csv;charset=utf-8');
        toast('CSV exporté');
      }),
    );

    root.querySelector('#shareReport').addEventListener(
      'click',
      guard(async () => {
        const s = stats();
        await shareText('Rapport Casabaia', `CASABAIA COLLECTE\nPoints: ${s.total}\nCollectés: ${s.collected}\nIncidents: ${s.totalIncidents}`);
      }),
    );

    root.querySelector('#importJson').addEventListener('change', async (e) => {
      const file = e.target.files[0];
      e.target.value = '';
      if (!file) return;
      try {
        const data = JSON.parse(await file.text());
        if (!Array.isArray(data.points)) throw new Error('invalide');
        const ok = await confirmDialog('Importer cette sauvegarde ?', `Les données actuelles (${state.points.length} points, ${state.incidents.length} constats) seront remplacées par celles du fichier.`, 'Importer');
        if (!ok) return;
        await importBackup(data);
        toast('Sauvegarde importée');
        app.refresh();
      } catch {
        toast('Fichier de sauvegarde invalide', 'error');
      }
    });
  },
};
