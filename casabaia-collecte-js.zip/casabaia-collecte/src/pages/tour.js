import { SECTORS, MAP_BBOX } from '../js/config.js';
import { state, setSession, resetTour, recordSaving } from '../database/store.js';
import { pageHead, statCard, emptyState, toast } from '../components/ui.js';
import { esc, todayISO } from '../services/format.js';
import { planTour } from '../services/geo.js';
import { ui } from '../js/ui-state.js';

const candidates = () => state.points.filter((p) => p.inTodayTour !== false && p.status !== 'collected');

export default {
  id: 'tour',
  title: 'Tournée du jour',
  render() {
    const toVisit = candidates();
    const session = state.session;
    const ordered = (session?.ids ?? []).map((id) => state.points.find((p) => p.id === id)).filter(Boolean);
    const sectorOptions = ['Tous', ...SECTORS].map((s) => `<option value="${esc(s)}" ${s === ui.tourSector ? 'selected' : ''}>${s === 'Tous' ? 'Tous les secteurs' : esc(s)}</option>`).join('');
    const bbox = MAP_BBOX.join('%2C');
    const list = ordered.length
      ? `<ol class="tour-list">${ordered
          .map((p) => `<li><span><b>${esc(p.name)}</b> — ${esc(p.neighborhood)}</span><a class="maplink" target="_blank" rel="noopener" href="https://www.openstreetmap.org/?mlat=${p.lat}&amp;mlon=${p.lng}#map=18/${p.lat}/${p.lng}">Carte</a></li>`)
          .join('')}</ol>${session?.savedKm != null ? `<p class="muted">Économie estimée par rapport à l'ordre de la liste : <b>${session.savedKm.toFixed(1)} km</b>.</p>` : ''}`
      : emptyState('Aucune tournée optimisée. Choisissez un secteur puis lancez l’optimisation.');

    return (
      pageHead('Exploitation', 'Tournée du jour', 'Organisation et optimisation locale des circuits') +
      `<div class="grid">
        ${statCard('Points à visiter', toVisit.length, 'Sélectionnés pour la tournée')}
        ${statCard('Points dans la tournée', ordered.length, 'Ordre optimisé actuel')}
        ${statCard('Distance estimée', session ? session.km + ' km' : '—', 'Estimation géographique')}
        ${statCard('Temps estimé', session ? session.minutes + ' min' : '—', 'À 25 km/h + service')}
      </div>
      <section class="panel"><h2>Préparer la tournée</h2>
        <div class="toolbar">
          <select id="tourSector" aria-label="Secteur de la tournée">${sectorOptions}</select>
          <button type="button" class="primary" id="optimize">Optimiser l'ordre</button>
          <button type="button" class="secondary" id="resetTour">Réinitialiser la sélection</button>
        </div>
        <p class="muted">Optimisation locale par plus proche voisin et coordonnées GPS. La distance est une estimation, pas un itinéraire routier garanti.</p>
        ${list}
      </section>
      <section class="panel"><h2>Carte des points</h2>
        <p class="muted">La carte nécessite une connexion Internet.</p>
        <iframe class="mapframe" title="Carte OpenStreetMap" loading="lazy" src="https://www.openstreetmap.org/export/embed.html?bbox=${bbox}&amp;layer=mapnik"></iframe>
      </section>`
    );
  },
  bind(root, app) {
    root.querySelector('#tourSector').addEventListener('change', (e) => (ui.tourSector = e.target.value));
    root.querySelector('#optimize').addEventListener('click', () => {
      ui.tourSector = root.querySelector('#tourSector').value;
      const selection = candidates().filter((p) => ui.tourSector === 'Tous' || p.neighborhood === ui.tourSector);
      if (!selection.length) return toast('Aucun point dans cette sélection');
      const plan = planTour(selection);
      setSession({ ids: plan.order.map((p) => p.id), km: plan.km, minutes: plan.minutes, savedKm: plan.savedKm, sector: ui.tourSector });
      recordSaving({ date: todayISO(), sector: ui.tourSector, km: plan.savedKm, points: plan.order.length });
      toast('Ordre de tournée optimisé');
      app.refresh();
    });
    root.querySelector('#resetTour').addEventListener('click', () => {
      resetTour();
      ui.tourSector = 'Tous';
      toast('Sélection réinitialisée');
      app.refresh();
    });
  },
};
