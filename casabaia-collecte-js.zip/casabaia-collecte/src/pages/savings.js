import { SAVINGS } from '../js/config.js';
import { state } from '../database/store.js';
import { pageHead, statCard, emptyState } from '../components/ui.js';
import { esc } from '../services/format.js';

export default {
  id: 'savings',
  title: 'Économies',
  render() {
    const total = state.savings.reduce((sum, e) => sum + (Number(e.km) || 0), 0);
    const liters = total / SAVINGS.kmPerLiter;
    const history = state.savings.length
      ? [...state.savings]
          .reverse()
          .map((e) => `<p class="saving-row"><span>${esc(e.date)}${e.sector ? ` · ${esc(e.sector === 'Tous' ? 'Tous secteurs' : e.sector)}` : ''}${e.points ? ` · ${e.points} points` : ''}</span><b>${(Number(e.km) || 0).toFixed(1)} km économisés</b></p>`)
          .join('')
      : emptyState('Aucune économie enregistrée pour le moment.');

    return (
      pageHead('Performance', 'Économies', 'Historique des distances estimées économisées') +
      `<div class="grid">
        ${statCard('Kilomètres économisés', total.toFixed(1) + ' km', 'Cumul enregistré')}
        ${statCard('Équivalent carburant', liters.toFixed(2) + ' L', `Hypothèse : ${SAVINGS.kmPerLiter} km / litre`)}
        ${statCard('Équivalent financier', Math.round(liters * SAVINGS.madPerLiter) + ' MAD', `Hypothèse : ${SAVINGS.madPerLiter} MAD / litre`)}
        ${statCard('Journées enregistrées', state.savings.length, 'Historique local')}
      </div>
      <section class="panel"><h2>Historique</h2>${history}</section>`
    );
  },
  bind() {},
};
