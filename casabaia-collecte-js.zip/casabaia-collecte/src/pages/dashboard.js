import { SECTORS } from '../js/config.js';
import { state, stats } from '../database/store.js';
import { pageHead, statCard, progress } from '../components/ui.js';
import { esc } from '../services/format.js';
import { ui } from '../js/ui-state.js';

export default {
  id: 'dashboard',
  title: 'Tableau de bord',
  render() {
    const s = stats();
    const sectors = SECTORS.map((sector) => {
      const pts = state.points.filter((p) => p.neighborhood === sector);
      const done = pts.filter((p) => p.status === 'collected').length;
      const pct = pts.length ? (done / pts.length) * 100 : 0;
      return `<button type="button" class="sector" data-sector="${esc(sector)}"><b>${esc(sector)}</b><small>${done} / ${pts.length} points collectés</small><div style="margin-top:12px">${progress(pct)}</div></button>`;
    }).join('');

    return (
      pageHead('Vue générale', 'Tableau de bord', 'Suivi opérationnel de la collecte à Casablanca') +
      `<div class="grid">
        ${statCard('Points enregistrés', s.total, 'Base de points chargée')}
        ${statCard('Points collectés', s.collected, `${s.collectedPct}% du parc`)}
        ${statCard('Points prioritaires', s.priority, 'À traiter en priorité')}
        ${statCard('Constats ouverts', s.openIncidents, 'Incidents non clôturés')}
      </div>
      <section class="panel"><h2>Suivi par secteur</h2><div class="sector-grid">${sectors}</div></section>
      <section class="panel"><h2>Accès rapides</h2><div class="actions">
        <button type="button" class="primary" data-go="tour">Démarrer une tournée</button>
        <button type="button" class="secondary" data-go="incidents">Signaler un incident</button>
        <button type="button" class="secondary" data-go="points">Consulter les points</button>
      </div></section>`
    );
  },
  bind(root, app) {
    root.querySelectorAll('[data-go]').forEach((b) => (b.onclick = () => app.navigate(b.dataset.go)));
    root.querySelectorAll('[data-sector]').forEach(
      (b) =>
        (b.onclick = () => {
          ui.sectorFilter = b.dataset.sector;
          app.navigate('points');
        }),
    );
  },
};
