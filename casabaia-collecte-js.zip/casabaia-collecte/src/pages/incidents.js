import { SECTORS, INCIDENT_TYPES, INCIDENT_STATUS } from '../js/config.js';
import { state, addIncident, closeIncident, getIncidentPhoto } from '../database/store.js';
import { pageHead, pill, emptyState, toast } from '../components/ui.js';
import { openModal } from '../components/modal.js';
import { esc, formatDateTime } from '../services/format.js';
import { getPosition } from '../services/geo.js';
import { compressImage, takeNativePhoto } from '../services/camera.js';
import { isNative } from '../services/platform.js';

function history() {
  if (!state.incidents.length) return emptyState('Aucun constat enregistré.');
  const list = [...state.incidents].sort((a, b) => String(b.date).localeCompare(String(a.date)));
  return `<div class="table-wrap"><table class="stack"><thead><tr><th>Date</th><th>Secteur</th><th>Type</th><th>Description</th><th>État</th><th>Action</th></tr></thead><tbody>${list
    .map((t) => {
      const open = t.status === INCIDENT_STATUS.open;
      const hasPhoto = !!(t.photo || t.photoId);
      const hasGps = t.lat !== '' && t.lat != null && t.lng !== '' && t.lng != null;
      return `<tr>
        <td data-label="Date">${esc(formatDateTime(t.date))}</td>
        <td data-label="Secteur">${esc(t.sector)}</td>
        <td data-label="Type">${esc(t.type)}</td>
        <td data-label="Description">${esc(t.description)}${hasGps ? `<br><small class="muted">GPS ${Number(t.lat).toFixed(5)}, ${Number(t.lng).toFixed(5)}</small>` : ''}</td>
        <td data-label="État">${pill(t.status, open ? 'priority' : 'collected')}</td>
        <td data-label="Action"><div class="actions">
          ${hasPhoto ? `<button type="button" class="smallbtn" data-photo="${esc(t.id)}">Photo</button>` : ''}
          ${open ? `<button type="button" class="smallbtn" data-close="${esc(t.id)}">Clôturer</button>` : ''}
        </div></td></tr>`;
    })
    .join('')}</tbody></table></div>`;
}

export default {
  id: 'incidents',
  title: 'Constats & incidents',
  render() {
    return (
      pageHead('Terrain', 'Constats & incidents', 'Enregistrer et suivre les anomalies opérationnelles') +
      `<section class="panel"><h2>Nouveau constat</h2>
        <form id="incidentForm" class="form-grid">
          <label>Secteur<select name="sector">${SECTORS.map((s) => `<option>${esc(s)}</option>`).join('')}</select></label>
          <label>Type<select name="type">${INCIDENT_TYPES.map((t) => `<option>${esc(t)}</option>`).join('')}</select></label>
          <label class="wide">Description<textarea name="description" rows="3" required placeholder="Décrire précisément l'anomalie..."></textarea></label>
          <div class="field">Photo
            <div class="actions"><button type="button" class="secondary" id="photoBtn">Prendre / choisir une photo</button><button type="button" class="smallbtn hidden" id="photoClear">Retirer</button></div>
            <input type="file" id="photoFile" accept="image/*" capture="environment" hidden>
            <img id="photoPreview" class="photo-preview hidden" alt="Aperçu de la photo">
          </div>
          <div class="field">Position GPS
            <button type="button" class="secondary" id="gps">Récupérer ma position</button>
            <small id="gpsText" class="muted">Position non récupérée</small>
          </div>
          <input type="hidden" name="lat"><input type="hidden" name="lng">
          <div class="wide"><button type="submit" class="primary">Enregistrer le constat</button></div>
        </form></section>
      <section class="panel"><h2>Historique (${state.incidents.length})</h2><div id="history">${history()}</div></section>`
    );
  },
  bind(root, app) {
    const form = root.querySelector('#incidentForm');
    const preview = root.querySelector('#photoPreview');
    const clearBtn = root.querySelector('#photoClear');
    let photoData = '';

    const setPhoto = (dataUrl) => {
      photoData = dataUrl || '';
      preview.src = photoData;
      preview.classList.toggle('hidden', !photoData);
      clearBtn.classList.toggle('hidden', !photoData);
    };

    root.querySelector('#photoBtn').addEventListener('click', async () => {
      if (isNative()) {
        try {
          const data = await takeNativePhoto();
          if (data) return setPhoto(data);
        } catch (err) {
          if (!/cancel/i.test(String(err?.message ?? err))) toast('Photo indisponible', 'error');
          return;
        }
      }
      root.querySelector('#photoFile').click();
    });
    root.querySelector('#photoFile').addEventListener('change', async (e) => {
      const file = e.target.files[0];
      if (!file) return;
      try {
        setPhoto(await compressImage(file));
      } catch {
        toast('Image illisible', 'error');
      }
    });
    clearBtn.addEventListener('click', () => setPhoto(''));

    root.querySelector('#gps').addEventListener('click', async (e) => {
      const btn = e.currentTarget;
      btn.disabled = true;
      try {
        const pos = await getPosition();
        form.elements.lat.value = pos.lat;
        form.elements.lng.value = pos.lng;
        root.querySelector('#gpsText').textContent = `GPS récupéré (${pos.lat.toFixed(5)}, ${pos.lng.toFixed(5)})`;
        toast('Position enregistrée dans le formulaire');
      } catch (err) {
        toast(err?.message === 'unavailable' ? 'GPS non disponible' : 'Position GPS inaccessible', 'error');
      } finally {
        btn.disabled = false;
      }
    });

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const fd = new FormData(form);
      const description = String(fd.get('description')).trim();
      if (!description) return toast('La description est obligatoire', 'error');
      await addIncident({
        sector: fd.get('sector'),
        type: fd.get('type'),
        description,
        photo: photoData,
        lat: fd.get('lat'),
        lng: fd.get('lng'),
      });
      toast('Constat enregistré');
      app.refresh();
    });

    root.querySelector('#history').addEventListener('click', async (e) => {
      const close = e.target.closest('[data-close]');
      if (close) {
        closeIncident(close.dataset.close);
        toast('Constat clôturé');
        return app.refresh();
      }
      const ph = e.target.closest('[data-photo]');
      if (ph) {
        const inc = state.incidents.find((i) => i.id === ph.dataset.photo);
        const src = inc ? await getIncidentPhoto(inc) : '';
        openModal({ title: 'Photo du constat', body: src ? `<img class="photo-full" alt="Photo du constat" src="${esc(src)}">` : '<p>Photo introuvable.</p>' });
      }
    });
  },
};
