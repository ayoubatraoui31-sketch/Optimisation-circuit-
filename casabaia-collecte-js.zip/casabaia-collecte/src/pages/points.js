import { SECTORS, STATUS_LABELS } from '../js/config.js';
import { state, setPointStatus, addPoint, updatePoint, deletePoint, getPoint } from '../database/store.js';
import { pageHead, pill, toast } from '../components/ui.js';
import { openModal, confirmDialog } from '../components/modal.js';
import { esc } from '../services/format.js';
import { ui } from '../js/ui-state.js';

function filtered() {
  const q = ui.search.trim().toLowerCase();
  return state.points.filter(
    (p) => (ui.sectorFilter === 'Tous' || p.neighborhood === ui.sectorFilter) && `${p.name} ${p.address} ${p.id}`.toLowerCase().includes(q),
  );
}

function rows() {
  const list = filtered();
  if (!list.length) return '<tr class="empty-row"><td colspan="6" class="empty">Aucun point trouvé</td></tr>';
  return list
    .map(
      (p) => `<tr>
      <td data-label="ID">${esc(p.id)}</td>
      <td data-label="Point"><b>${esc(p.name)}</b><br><span class="muted">${esc(p.address)}</span></td>
      <td data-label="Secteur">${esc(p.neighborhood)}</td>
      <td data-label="Remplissage">${p.fillLevel}%</td>
      <td data-label="État">${pill(STATUS_LABELS[p.status] || p.status, p.status)}</td>
      <td data-label="Actions"><div class="actions">
        <button type="button" class="smallbtn" data-status="${esc(p.id)}" data-value="collected">Collecté</button>
        <button type="button" class="smallbtn" data-status="${esc(p.id)}" data-value="priority">Priorité</button>
        <button type="button" class="smallbtn" data-status="${esc(p.id)}" data-value="skipped">Ignorer</button>
        <button type="button" class="smallbtn" data-status="${esc(p.id)}" data-value="toCollect">Réinitialiser</button>
        <button type="button" class="smallbtn" data-edit="${esc(p.id)}">Modifier</button>
      </div></td></tr>`,
    )
    .join('');
}

function pointForm(p = {}) {
  const sectorOptions = SECTORS.map((s) => `<option ${s === (p.neighborhood || SECTORS[0]) ? 'selected' : ''}>${esc(s)}</option>`).join('');
  return `<form id="pointForm" class="form-grid" novalidate>
    <label class="wide">Nom du point<input class="input" name="name" required value="${esc(p.name ?? '')}" placeholder="Ex. Benne Hay Adil 12"></label>
    <label>Secteur<select name="neighborhood">${sectorOptions}</select></label>
    <label>Remplissage (%)<input class="input" name="fillLevel" type="number" min="0" max="100" step="5" value="${p.fillLevel ?? 0}"></label>
    <label>Latitude GPS<input class="input" name="lat" type="number" step="any" required value="${p.lat ?? '33.5920'}" inputmode="decimal"></label>
    <label>Longitude GPS<input class="input" name="lng" type="number" step="any" required value="${p.lng ?? '-7.5700'}" inputmode="decimal"></label>
    <label class="wide">Adresse / repère<input class="input" name="address" value="${esc(p.address ?? '')}"></label>
    <p class="form-error wide hidden" id="pointError" role="alert"></p>
  </form>`;
}

async function editPoint(app, id) {
  const existing = id ? getPoint(id) : null;
  let result;
  const action = await openModal({
    title: existing ? 'Modifier le point' : 'Ajouter un point',
    body: pointForm(existing || {}),
    actions: [
      ...(existing ? [{ label: 'Supprimer', kind: 'danger', value: 'delete' }] : []),
      { label: 'Annuler', kind: 'secondary', value: 'cancel' },
      { label: 'Enregistrer', kind: 'primary', value: 'save' },
    ],
    onOpen(modal, close) {
      // L'enregistrement est validé avant de fermer la fenêtre.
      const save = modal.querySelector('[data-modal-action][class="primary"]');
      save.addEventListener(
        'click',
        (e) => {
          const form = modal.querySelector('#pointForm');
          const fd = new FormData(form);
          const name = String(fd.get('name')).trim();
          const lat = Number(fd.get('lat'));
          const lng = Number(fd.get('lng'));
          const err = modal.querySelector('#pointError');
          if (!name || !Number.isFinite(lat) || !Number.isFinite(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) {
            e.stopImmediatePropagation();
            err.textContent = !name ? 'Le nom est obligatoire.' : 'Coordonnées GPS invalides.';
            err.classList.remove('hidden');
            return;
          }
          result = {
            name,
            neighborhood: String(fd.get('neighborhood')),
            address: String(fd.get('address')).trim() || name,
            lat,
            lng,
            fillLevel: Number(fd.get('fillLevel')) || 0,
          };
        },
        true,
      );
    },
  });

  if (action === 'save' && result) {
    if (existing) updatePoint(id, result);
    else {
      addPoint(result);
      // Rend le nouveau point visible : on vide la recherche et on filtre sur son secteur.
      ui.search = '';
      ui.sectorFilter = result.neighborhood;
    }
    toast(existing ? 'Point mis à jour' : 'Point ajouté');
    app.refresh();
  } else if (action === 'delete') {
    if (await confirmDialog('Supprimer ce point ?', `« ${existing.name} » sera retiré de la base locale.`, 'Supprimer')) {
      deletePoint(id);
      toast('Point supprimé');
      app.refresh();
    }
  }
}

export default {
  id: 'points',
  title: 'Points de collecte',
  render() {
    const options = ['Tous', ...SECTORS].map((s) => `<option ${s === ui.sectorFilter ? 'selected' : ''}>${esc(s)}</option>`).join('');
    return (
      pageHead('Base opérationnelle', 'Points de collecte', 'Gestion des bennes, conteneurs et priorités', '<button type="button" class="primary" id="addPoint">+ Ajouter un point</button>') +
      `<div class="toolbar">
        <input class="input" id="search" type="search" placeholder="Rechercher un point..." aria-label="Rechercher un point" value="${esc(ui.search)}">
        <select id="sectorFilter" aria-label="Filtrer par secteur">${options}</select>
      </div>
      <div class="table-wrap"><table class="stack"><thead><tr><th>ID</th><th>Point / adresse</th><th>Secteur</th><th>Remplissage</th><th>État</th><th>Actions</th></tr></thead><tbody>${rows()}</tbody></table></div>`
    );
  },
  bind(root, app) {
    const tbody = root.querySelector('tbody');
    root.querySelector('#search').addEventListener('input', (e) => {
      ui.search = e.target.value;
      tbody.innerHTML = rows();
    });
    root.querySelector('#sectorFilter').addEventListener('change', (e) => {
      ui.sectorFilter = e.target.value;
      app.refresh();
    });
    root.querySelector('#addPoint').addEventListener('click', () => editPoint(app, null));
    // Délégation : le contenu du tableau est régénéré à chaque recherche.
    tbody.addEventListener('click', (e) => {
      const st = e.target.closest('[data-status]');
      if (st) {
        setPointStatus(st.dataset.status, st.dataset.value);
        toast('État du point mis à jour');
        return app.refresh();
      }
      const ed = e.target.closest('[data-edit]');
      if (ed) editPoint(app, ed.dataset.edit);
    });
  },
};
