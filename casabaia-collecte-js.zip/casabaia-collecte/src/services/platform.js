/**
 * Accès aux fonctions natives Capacitor, avec repli web.
 * Sans bundler, les plugins sont exposés via window.Capacitor.Plugins
 * (injecté par l'application Android).
 */
export function isNative() {
  try {
    return !!window.Capacitor?.isNativePlatform?.();
  } catch {
    return false;
  }
}

/** @returns le plugin natif demandé, ou null en mode navigateur / si non installé. */
export function getPlugin(name) {
  if (!isNative()) return null;
  return window.Capacitor?.Plugins?.[name] ?? null;
}
