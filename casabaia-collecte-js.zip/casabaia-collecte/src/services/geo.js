import { DEPOT, TOUR } from '../js/config.js';
import { getPlugin } from './platform.js';

const R = 6371e3; // rayon terrestre (m)
const rad = Math.PI / 180;

/** Distance à vol d'oiseau en mètres (formule de haversine). */
export function haversine(a, b) {
  const dLat = (b.lat - a.lat) * rad;
  const dLng = (b.lng - a.lng) * rad;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(a.lat * rad) * Math.cos(b.lat * rad) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

/** Ordre « plus proche voisin » à partir du dépôt. Ne modifie pas le tableau reçu. */
export function nearestNeighbor(points, start = DEPOT) {
  const rest = [...points];
  const order = [];
  let current = start;
  while (rest.length) {
    let best = 0;
    let bestDist = Infinity;
    for (let i = 0; i < rest.length; i++) {
      const d = haversine(current, rest[i]);
      if (d < bestDist) {
        bestDist = d;
        best = i;
      }
    }
    current = rest.splice(best, 1)[0];
    order.push(current);
  }
  return order;
}

/** Distance routière estimée (km) d'un circuit dépôt → points → dépôt. */
export function routeKm(order, depot = DEPOT) {
  if (!order.length) return 0;
  let meters = 0;
  let current = depot;
  for (const p of order) {
    meters += haversine(current, p);
    current = p;
  }
  meters += haversine(current, depot);
  return (meters * TOUR.roadFactor) / 1000;
}

export function estimateMinutes(km, stops) {
  return Math.round((km / TOUR.speedKmh) * 60 + stops * TOUR.serviceMinPerPoint);
}

/**
 * Optimise une sélection de points.
 * `savedKm` compare au parcours dans l'ordre de la liste (ordre non optimisé).
 */
export function planTour(points) {
  const order = nearestNeighbor(points);
  const km = routeKm(order);
  const baselineKm = routeKm(points);
  return {
    order,
    km: Number(km.toFixed(1)),
    minutes: estimateMinutes(km, order.length),
    baselineKm: Number(baselineKm.toFixed(1)),
    savedKm: Math.max(0, Number((baselineKm - km).toFixed(1))),
  };
}

/** Position GPS (plugin natif Capacitor si disponible, sinon API web). */
export async function getPosition() {
  const native = getPlugin('Geolocation');
  if (native) {
    const perm = await native.requestPermissions().catch(() => null);
    if (perm && perm.location === 'denied') throw new Error('denied');
    const pos = await native.getCurrentPosition({ enableHighAccuracy: true, timeout: 12000 });
    return { lat: pos.coords.latitude, lng: pos.coords.longitude };
  }
  if (!('geolocation' in navigator)) throw new Error('unavailable');
  return new Promise((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(
      (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      reject,
      { enableHighAccuracy: true, timeout: 12000 },
    );
  });
}
