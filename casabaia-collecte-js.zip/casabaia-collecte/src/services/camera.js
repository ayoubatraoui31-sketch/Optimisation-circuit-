import { getPlugin } from './platform.js';

/** Réduit une image (côté max 1280 px, JPEG 0,72) pour économiser le stockage. */
export function compressImage(file, maxSide = 1280, quality = 0.72) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(reader.error);
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => resolve(reader.result); // format non décodable : on garde l'original
      img.onload = () => {
        const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.round(img.width * scale);
        canvas.height = Math.round(img.height * scale);
        canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

/**
 * Photo via la caméra native (Android) ; renvoie null si l'on doit utiliser
 * le sélecteur de fichier web (navigateur).
 */
export async function takeNativePhoto() {
  const cam = getPlugin('Camera');
  if (!cam) return null;
  const photo = await cam.getPhoto({ quality: 72, width: 1280, resultType: 'dataUrl', source: 'PROMPT' });
  return photo.dataUrl ?? null;
}
