import { getPlugin } from './platform.js';

/**
 * Enregistre un fichier texte puis le propose à l'utilisateur.
 * - Android (Capacitor) : écriture dans le cache + feuille de partage native
 *   (les téléchargements « blob » ne fonctionnent pas dans la WebView).
 * - Navigateur : téléchargement classique.
 */
export async function saveTextFile(filename, content, mime) {
  const fs = getPlugin('Filesystem');
  const share = getPlugin('Share');
  if (fs && share) {
    const written = await fs.writeFile({ path: filename, data: content, directory: 'CACHE', encoding: 'utf8' });
    await share.share({ title: filename, url: written.uri, dialogTitle: 'Enregistrer ou partager' });
    return 'shared';
  }
  const url = URL.createObjectURL(new Blob([content], { type: mime }));
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  return 'downloaded';
}

export async function shareText(title, text) {
  const share = getPlugin('Share');
  if (share) {
    await share.share({ title, text });
    return 'shared';
  }
  if (navigator.share) {
    await navigator.share({ title, text });
    return 'shared';
  }
  await saveTextFile('rapport-casabaia.txt', text, 'text/plain');
  return 'downloaded';
}

/** CSV compatible Excel (séparateur « ; », BOM UTF-8), comme l'original. */
export function toCsv(rows) {
  const cell = (v) => '"' + String(v ?? '').replaceAll('"', '""') + '"';
  return '\uFEFF' + rows.map((r) => r.map(cell).join(';')).join('\n');
}
