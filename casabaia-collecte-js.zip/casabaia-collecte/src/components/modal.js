import { esc } from '../services/format.js';

/**
 * Boîte de dialogue légère.
 * @param {{title:string, body:string, actions?:Array<{label:string,kind?:string,value:any}>}} opts
 * @returns {Promise<any>} la `value` de l'action choisie, ou undefined si fermée
 */
export function openModal({ title, body, actions = [], onOpen }) {
  return new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `<div class="modal" role="dialog" aria-modal="true" aria-label="${esc(title)}">
      <div class="modal-head"><h2>${esc(title)}</h2><button type="button" class="modal-x" data-modal-close aria-label="Fermer">×</button></div>
      <div class="modal-body">${body}</div>
      ${actions.length ? `<div class="modal-foot">${actions.map((a, i) => `<button type="button" class="${esc(a.kind || 'secondary')}" data-modal-action="${i}">${esc(a.label)}</button>`).join('')}</div>` : ''}
    </div>`;
    const modal = overlay.firstElementChild;

    const close = (value) => {
      document.removeEventListener('keydown', onKey);
      overlay.remove();
      resolve(value);
    };
    const onKey = (e) => e.key === 'Escape' && close(undefined);

    overlay.addEventListener('click', (e) => {
      if (e.target === overlay || e.target.closest('[data-modal-close]')) return close(undefined);
      const btn = e.target.closest('[data-modal-action]');
      if (btn) close(actions[Number(btn.dataset.modalAction)].value);
    });
    document.addEventListener('keydown', onKey);
    document.body.append(overlay);
    onOpen?.(modal, close);
    (modal.querySelector('[autofocus], input, select, textarea, button.primary') || modal).focus?.();
  });
}

export const confirmDialog = (title, message, confirmLabel = 'Confirmer') =>
  openModal({
    title,
    body: `<p>${esc(message)}</p>`,
    actions: [
      { label: 'Annuler', kind: 'secondary', value: false },
      { label: confirmLabel, kind: 'primary', value: true },
    ],
  });
