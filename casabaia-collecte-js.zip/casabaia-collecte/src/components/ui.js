import { esc } from '../services/format.js';

export function pageHead(eyebrow, title, sub, actionHtml = '') {
  return `<div class="page-head"><div><div class="eyebrow">${esc(eyebrow)}</div><h1>${esc(title)}</h1><p class="sub">${esc(sub)}</p></div>${actionHtml}</div>`;
}

export function statCard(label, value, note) {
  return `<div class="card"><div class="stat-label">${esc(label)}</div><div class="stat-value">${esc(value)}</div><div class="stat-note">${esc(note)}</div></div>`;
}

export const pill = (label, cls = '') => `<span class="pill ${esc(cls)}">${esc(label)}</span>`;

export const emptyState = (text) => `<div class="empty">${esc(text)}</div>`;

export function progress(pct) {
  return `<div class="progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${Math.round(pct)}"><span style="width:${Math.max(0, Math.min(100, pct))}%"></span></div>`;
}

/** Notifications empilées (plusieurs messages successifs ne se superposent plus). */
export function toast(message, kind = 'info') {
  let box = document.querySelector('#toasts');
  if (!box) {
    box = document.createElement('div');
    box.id = 'toasts';
    box.setAttribute('aria-live', 'polite');
    document.body.append(box);
  }
  const el = document.createElement('div');
  el.className = 'toast' + (kind === 'error' ? ' error' : '');
  el.setAttribute('role', 'status');
  el.textContent = message;
  box.append(el);
  setTimeout(() => el.remove(), 2800);
}
