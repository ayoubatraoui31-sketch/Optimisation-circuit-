import { SEED_POINTS } from './seed.js';
import { readKey, writeKey } from './storage.js';
import { putPhoto, getPhoto, deletePhoto, clearPhotos } from './photos.js';
import { INCIDENT_STATUS, SECTORS } from '../js/config.js';

const VALID_STATUS = ['toCollect', 'priority', 'collected', 'skipped'];

const clamp = (n, min, max) => Math.min(max, Math.max(min, n));

export function normalizePoint(p) {
  return {
    id: String(p.id),
    name: String(p.name ?? p.id),
    neighborhood: p.neighborhood ?? SECTORS[0],
    address: p.address ?? p.name ?? '',
    lat: Number(p.lat),
    lng: Number(p.lng),
    status: VALID_STATUS.includes(p.status) ? p.status : 'toCollect',
    inTodayTour: p.inTodayTour !== false,
    fillLevel: clamp(Number(p.fillLevel) || 0, 0, 100),
    priorityLevel: clamp(Number(p.priorityLevel) || 1, 1, 5),
  };
}

const isValidPoint = (p) => p && p.id != null && Number.isFinite(Number(p.lat)) && Number.isFinite(Number(p.lng));

/** État en mémoire, persisté dans localStorage (clés cc_points, cc_incidents, cc_savings, cc_session). */
export const state = {
  points: [],
  incidents: [],
  savings: [],
  session: null,
};

let onStorageError = () => {};
export const setStorageErrorHandler = (fn) => (onStorageError = fn);

export function load() {
  const savedPoints = readKey('points', null);
  state.points = (Array.isArray(savedPoints) ? savedPoints : SEED_POINTS).filter(isValidPoint).map(normalizePoint);
  state.incidents = readKey('incidents', []);
  state.savings = readKey('savings', []);
  state.session = readKey('session', null);
  if (!Array.isArray(state.incidents)) state.incidents = [];
  if (!Array.isArray(state.savings)) state.savings = [];
}

export function persist() {
  const ok = [
    writeKey('points', state.points),
    writeKey('incidents', state.incidents),
    writeKey('savings', state.savings),
    writeKey('session', state.session),
  ].every(Boolean);
  if (!ok) onStorageError();
  return ok;
}

/** Déplace les photos base64 de l'ancien format vers IndexedDB. */
export async function migrateLegacyPhotos() {
  let changed = false;
  for (const inc of state.incidents) {
    if (typeof inc.photo === 'string' && inc.photo.startsWith('data:')) {
      try {
        const photoId = 'ph-' + inc.id;
        await putPhoto(photoId, inc.photo);
        inc.photoId = photoId;
        delete inc.photo;
        changed = true;
      } catch (err) {
        console.warn('[migration] photo conservée en ligne pour', inc.id, err);
      }
    } else if ('photo' in inc && !inc.photo) {
      delete inc.photo;
      changed = true;
    }
  }
  if (changed) persist();
}

/* ---------- Points ---------- */

export const getPoint = (id) => state.points.find((p) => p.id === id);

export function setPointStatus(id, status) {
  const p = getPoint(id);
  if (!p || !VALID_STATUS.includes(status)) return false;
  p.status = status;
  persist();
  return true;
}

export function addPoint(data) {
  const p = normalizePoint({ ...data, id: 'p' + Date.now() });
  state.points.push(p);
  persist();
  return p;
}

export function updatePoint(id, data) {
  const idx = state.points.findIndex((p) => p.id === id);
  if (idx < 0) return null;
  state.points[idx] = normalizePoint({ ...state.points[idx], ...data, id });
  persist();
  return state.points[idx];
}

export function deletePoint(id) {
  state.points = state.points.filter((p) => p.id !== id);
  if (state.session) {
    state.session.ids = state.session.ids.filter((x) => x !== id);
    if (!state.session.ids.length) state.session = null;
  }
  persist();
}

/* ---------- Tournée & économies ---------- */

export function setSession(session) {
  state.session = session;
  persist();
}

export function resetTour() {
  state.points.forEach((p) => (p.inTodayTour = true));
  state.session = null;
  persist();
}

/** Une entrée par jour et par secteur : relancer l'optimisation met l'entrée à jour. */
export function recordSaving({ date, sector, km, points }) {
  const entry = { date, sector, km, points };
  const idx = state.savings.findIndex((s) => s.date === date && s.sector === sector);
  if (idx >= 0) state.savings[idx] = entry;
  else state.savings.push(entry);
  persist();
}

/* ---------- Constats ---------- */

export async function addIncident({ sector, type, description, photo, lat, lng }) {
  const id = 'INC-' + Date.now();
  const incident = {
    id,
    date: new Date().toISOString(),
    sector,
    type,
    description,
    lat: lat ?? '',
    lng: lng ?? '',
    status: INCIDENT_STATUS.open,
  };
  if (photo) {
    try {
      await putPhoto('ph-' + id, photo);
      incident.photoId = 'ph-' + id;
    } catch {
      incident.photo = photo; // repli : stockage en ligne si IndexedDB est indisponible
    }
  }
  state.incidents.push(incident);
  persist();
  return incident;
}

export function closeIncident(id) {
  const inc = state.incidents.find((i) => i.id === id);
  if (!inc) return false;
  inc.status = INCIDENT_STATUS.closed;
  persist();
  return true;
}

export async function getIncidentPhoto(inc) {
  if (inc.photo) return inc.photo;
  if (inc.photoId) return (await getPhoto(inc.photoId)) ?? '';
  return '';
}

/* ---------- Sauvegarde / import ---------- */

/** Format compatible avec la sauvegarde de l'application d'origine (photos incluses en base64). */
export async function exportBackup() {
  const incidents = [];
  for (const inc of state.incidents) {
    const { photoId, ...rest } = inc;
    const photo = await getIncidentPhoto(inc);
    incidents.push(photo ? { ...rest, photo } : rest);
  }
  return {
    app: 'casabaia-collecte',
    points: state.points,
    incidents,
    savings: state.savings,
    session: state.session,
    exportedAt: new Date().toISOString(),
  };
}

export async function importBackup(data) {
  if (!data || !Array.isArray(data.points)) throw new Error('Fichier de sauvegarde invalide');
  const points = data.points.filter(isValidPoint).map(normalizePoint);
  if (!points.length && data.points.length) throw new Error('Fichier de sauvegarde invalide');
  await clearPhotos();
  state.points = points;
  state.incidents = Array.isArray(data.incidents) ? data.incidents : [];
  state.savings = Array.isArray(data.savings) ? data.savings : [];
  state.session = data.session && Array.isArray(data.session.ids) ? data.session : null;
  await migrateLegacyPhotos();
  persist();
}

/* ---------- Indicateurs ---------- */

export function stats() {
  const { points, incidents } = state;
  const collected = points.filter((p) => p.status === 'collected').length;
  const priority = points.filter((p) => p.priorityLevel >= 3 || p.fillLevel >= 80 || p.status === 'priority').length;
  return {
    total: points.length,
    collected,
    skipped: points.filter((p) => p.status === 'skipped').length,
    priority,
    openIncidents: incidents.filter((i) => i.status === INCIDENT_STATUS.open).length,
    totalIncidents: incidents.length,
    collectedPct: points.length ? Math.round((collected / points.length) * 100) : 0,
  };
}

export { deletePhoto };
