import { STORAGE_PREFIX } from '../js/config.js';

/** Lecture/écriture JSON dans localStorage, sans jamais lever d'exception. */
export function readKey(key, fallback) {
  try {
    const raw = localStorage.getItem(STORAGE_PREFIX + key);
    if (raw === null) return fallback;
    return JSON.parse(raw) ?? fallback;
  } catch {
    return fallback;
  }
}

/** @returns {boolean} false si l'écriture a échoué (quota dépassé, stockage désactivé…) */
export function writeKey(key, value) {
  try {
    localStorage.setItem(STORAGE_PREFIX + key, JSON.stringify(value));
    return true;
  } catch (err) {
    console.error('[storage] écriture impossible pour', key, err);
    return false;
  }
}
