/**
 * Stockage des photos de constats dans IndexedDB.
 * (L'original les stockait en base64 dans localStorage, limité à ~5 Mo.)
 */
const DB_NAME = 'casabaia-collecte';
const STORE = 'photos';

function open() {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') return reject(new Error('IndexedDB indisponible'));
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function tx(mode, fn) {
  const db = await open();
  return new Promise((resolve, reject) => {
    const t = db.transaction(STORE, mode);
    const req = fn(t.objectStore(STORE));
    t.oncomplete = () => {
      db.close();
      resolve(req?.result);
    };
    t.onerror = t.onabort = () => {
      db.close();
      reject(t.error);
    };
  });
}

export const putPhoto = (id, dataUrl) => tx('readwrite', (s) => s.put(dataUrl, id));
export const getPhoto = (id) => tx('readonly', (s) => s.get(id)).catch(() => undefined);
export const deletePhoto = (id) => tx('readwrite', (s) => s.delete(id)).catch(() => undefined);
export const clearPhotos = () => tx('readwrite', (s) => s.clear()).catch(() => undefined);
