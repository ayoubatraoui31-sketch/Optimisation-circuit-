/**
 * Constantes métier de Casabaia Collecte.
 * Les valeurs numériques sont celles de l'application d'origine.
 */
export const APP = {
  name: 'Casabaia Collecte',
  version: '4.0.0',
  label: 'COLLECTE · V4.0 JS',
};

/** Secteurs (l'ordre est celui de l'application d'origine). */
export const SECTORS = ['Hay Adil', 'Belvédère', 'Roches Noires', 'Aïn Borja', 'Al Bayda'];

/** Point de départ / retour des tournées (centre de la zone couverte). */
export const DEPOT = { lat: 33.5985, lng: -7.586 };

export const TOUR = {
  roadFactor: 1.3, // distance routière ≈ 1,3 × distance à vol d'oiseau
  speedKmh: 25, // vitesse moyenne
  serviceMinPerPoint: 3, // temps de service par point
};

export const SAVINGS = {
  kmPerLiter: 10, // hypothèse : 10 km / litre
  madPerLiter: 13, // hypothèse : 13 MAD / litre
};

export const STATUS_LABELS = {
  toCollect: 'À collecter',
  priority: 'Prioritaire',
  collected: 'Collecté',
  skipped: 'Ignoré',
};

export const INCIDENT_TYPES = [
  'Benne pleine',
  'Obstacle',
  'Dépôt sauvage',
  'Véhicule bloquant',
  'Déchet vert',
  'Encombrants',
  'Autre',
];

export const INCIDENT_STATUS = { open: 'ouvert', closed: 'clôturé' };

/** Emprise de la carte OpenStreetMap intégrée (ouest, sud, est, nord). */
export const MAP_BBOX = [-7.62, 33.57, -7.54, 33.62];

/** Préfixe des clés localStorage — identique à l'original pour conserver les données existantes. */
export const STORAGE_PREFIX = 'cc_';
