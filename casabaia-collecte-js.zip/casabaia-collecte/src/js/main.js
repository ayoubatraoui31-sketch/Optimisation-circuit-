import { APP } from './config.js';
import { load, migrateLegacyPhotos, setStorageErrorHandler } from '../database/store.js';
import { toast } from '../components/ui.js';
import { isNative } from '../services/platform.js';
import dashboard from '../pages/dashboard.js';
import points from '../pages/points.js';
import tour from '../pages/tour.js';
import incidents from '../pages/incidents.js';
import savings from '../pages/savings.js';
import report from '../pages/report.js';

const pages = Object.fromEntries([dashboard, points, tour, incidents, savings, report].map((p) => [p.id, p]));
const root = document.querySelector('#app');
let current = 'dashboard';

const app = {
  navigate(id) {
    if (location.hash === '#' + id) render(id);
    else location.hash = id; // déclenche « hashchange » (le bouton Retour d'Android fonctionne)
  },
  /** Réaffiche la page courante en conservant la position de défilement. */
  refresh() {
    const y = window.scrollY;
    render(current, { keepScroll: true });
    window.scrollTo(0, y);
  },
};

function render(id, { keepScroll = false } = {}) {
  const page = pages[id] ?? pages.dashboard;
  current = page.id;
  document.title = `${page.title} · ${APP.name}`;
  document.querySelectorAll('[data-page]').forEach((el) => {
    const active = el.dataset.page === current;
    el.classList.toggle('active', active);
    if (active) el.setAttribute('aria-current', 'page');
    else el.removeAttribute('aria-current');
  });
  try {
    root.innerHTML = page.render();
    page.bind(root, app);
  } catch (err) {
    console.error('[render]', current, err);
    root.innerHTML = '<div class="panel"><h2>Erreur d\'affichage</h2><p class="muted">Cette page n\'a pas pu être affichée. Rechargez l\'application.</p></div>';
  }
  if (!keepScroll) window.scrollTo(0, 0);
}

function init() {
  document.querySelector('#appLabel').textContent = APP.label;
  setStorageErrorHandler(() => toast('Stockage plein ou indisponible : données non sauvegardées', 'error'));
  load();
  migrateLegacyPhotos();

  document.querySelectorAll('[data-page]').forEach((el) => el.addEventListener('click', () => app.navigate(el.dataset.page)));
  window.addEventListener('hashchange', () => render(location.hash.slice(1)));
  render(location.hash.slice(1));

  // Installation PWA (navigateur uniquement) + mode hors ligne
  if (!isNative()) {
    const installBtn = document.querySelector('#installBtn');
    let deferred;
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      deferred = e;
      installBtn.classList.remove('hidden');
    });
    installBtn.addEventListener('click', async () => {
      if (!deferred) return;
      deferred.prompt();
      deferred = null;
      installBtn.classList.add('hidden');
    });
    if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
      window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(() => {}));
    }
  }
}

init();

// Exposé pour le débogage et les tests de bout en bout.
window.__casabaia = { app, pages };
