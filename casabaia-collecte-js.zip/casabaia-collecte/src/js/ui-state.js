/** État d'interface éphémère (filtres, sélection) conservé entre deux rendus. */
export const ui = {
  sectorFilter: 'Tous',
  search: '',
  tourSector: 'Tous',
};
