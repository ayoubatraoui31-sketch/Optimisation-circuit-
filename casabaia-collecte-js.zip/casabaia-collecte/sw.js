/* Service worker : application utilisable hors ligne (hors carte OpenStreetMap).
   La liste PRECACHE et la version sont injectées par scripts/build.mjs. */
const VERSION = '__VERSION__';
const CACHE = 'casabaia-' + VERSION;
const PRECACHE = self.__PRECACHE__ || [];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE).then((c) => c.addAll(PRECACHE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k.startsWith('casabaia-') && k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()),
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  const url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== location.origin) return; // laisse passer OpenStreetMap, etc.
  event.respondWith(
    caches.match(req, { ignoreSearch: true }).then((hit) => {
      const network = fetch(req)
        .then((res) => {
          if (res.ok) caches.open(CACHE).then((c) => c.put(req, res.clone()));
          return res;
        })
        .catch(() => hit || caches.match('./index.html'));
      return hit || network; // cache d'abord, mise à jour en arrière-plan
    }),
  );
});
