import test, { beforeEach } from 'node:test';
import assert from 'node:assert/strict';

// Simule localStorage pour tester le store hors navigateur
const mem = new Map();
globalThis.localStorage = {
  getItem: (k) => (mem.has(k) ? mem.get(k) : null),
  setItem: (k, v) => mem.set(k, String(v)),
  removeItem: (k) => mem.delete(k),
};

const store = await import('../../src/database/store.js');
const { SEED_POINTS } = await import('../../src/database/seed.js');
const { esc } = await import('../../src/services/format.js');
const { toCsv } = await import('../../src/services/files.js');
const { SECTORS } = await import('../../src/js/config.js');

beforeEach(() => {
  mem.clear();
  store.load();
});

test('base initiale : 50 points, ids uniques, coordonnées à Casablanca, secteurs connus', () => {
  assert.equal(SEED_POINTS.length, 50);
  assert.equal(new Set(SEED_POINTS.map((p) => p.id)).size, 50);
  for (const p of SEED_POINTS) {
    assert.ok(p.lat > 33.5 && p.lat < 33.7 && p.lng > -7.7 && p.lng < -7.5, p.id);
    assert.ok(SECTORS.includes(p.neighborhood), p.id);
  }
  assert.equal(SEED_POINTS.filter((p) => p.status === 'priority').length, 4);
});

test('premier lancement : points d’origine, stats cohérentes', () => {
  const s = store.stats();
  assert.equal(s.total, 50);
  assert.equal(s.collected, 0);
  assert.equal(s.priority, 4);
  assert.equal(s.openIncidents, 0);
});

test('statut d’un point : persisté et rechargé', () => {
  assert.ok(store.setPointStatus('p1', 'collected'));
  assert.equal(store.setPointStatus('p1', 'nimportequoi'), false);
  store.load();
  assert.equal(store.getPoint('p1').status, 'collected');
  assert.equal(store.stats().collectedPct, 2);
});

test('ajout / modification / suppression d’un point', () => {
  const p = store.addPoint({ name: 'Benne Test', neighborhood: 'Al Bayda', lat: 33.59, lng: -7.6, fillLevel: 90 });
  assert.equal(store.state.points.length, 51);
  assert.equal(store.stats().priority, 5, 'un remplissage ≥ 80 % rend le point prioritaire');
  store.updatePoint(p.id, { fillLevel: 10 });
  assert.equal(store.stats().priority, 4);
  store.deletePoint(p.id);
  assert.equal(store.state.points.length, 50);
});

test('suppression d’un point retiré de la tournée en cours', () => {
  store.setSession({ ids: ['p1', 'p2'], km: 1, minutes: 1 });
  store.deletePoint('p1');
  assert.deepEqual(store.state.session.ids, ['p2']);
  store.deletePoint('p2');
  assert.equal(store.state.session, null);
});

test('économies : une entrée par jour et par secteur', () => {
  store.recordSaving({ date: '2026-11-10', sector: 'Tous', km: 2, points: 50 });
  store.recordSaving({ date: '2026-11-10', sector: 'Tous', km: 3, points: 50 });
  store.recordSaving({ date: '2026-11-10', sector: 'Hay Adil', km: 1, points: 11 });
  assert.equal(store.state.savings.length, 2);
  assert.equal(store.state.savings.find((s) => s.sector === 'Tous').km, 3);
});

test('constats : ajout, clôture, compteur d’ouverts', async () => {
  const inc = await store.addIncident({ sector: 'Hay Adil', type: 'Benne pleine', description: 'Test', photo: '', lat: '', lng: '' });
  assert.equal(store.stats().openIncidents, 1);
  assert.ok(store.closeIncident(inc.id));
  assert.equal(store.stats().openIncidents, 0);
  assert.equal(store.stats().totalIncidents, 1);
});

test('sauvegarde : export puis import restaure les données', async () => {
  store.setPointStatus('p2', 'priority');
  await store.addIncident({ sector: 'Belvédère', type: 'Obstacle', description: 'x', photo: '', lat: '', lng: '' });
  const backup = await store.exportBackup();
  mem.clear();
  store.load();
  assert.equal(store.getPoint('p2').status, 'toCollect');
  await store.importBackup(JSON.parse(JSON.stringify(backup)));
  assert.equal(store.getPoint('p2').status, 'priority');
  assert.equal(store.state.incidents.length, 1);
});

test('import : refuse les fichiers invalides sans toucher aux données', async () => {
  await assert.rejects(() => store.importBackup({ foo: 1 }));
  await assert.rejects(() => store.importBackup(null));
  await assert.rejects(() => store.importBackup({ points: [{ id: 'x', lat: 'abc', lng: 1 }] }));
  assert.equal(store.state.points.length, 50);
});

test('compatibilité : lit les clés cc_* de l’ancienne application', () => {
  mem.set('cc_points', JSON.stringify([{ id: 'p1', name: 'Ancien', neighborhood: 'Hay Adil', lat: 33.58, lng: -7.55, status: 'collected', inTodayTour: true }]));
  mem.set('cc_incidents', JSON.stringify([{ id: 'INC-1', date: '2026-01-01T00:00:00Z', sector: 'Hay Adil', type: 'Autre', description: 'd', photo: '', lat: '', lng: '', status: 'ouvert' }]));
  mem.set('cc_savings', JSON.stringify([{ date: '2026-01-01', km: 0 }]));
  store.load();
  assert.equal(store.state.points.length, 1);
  assert.equal(store.state.points[0].fillLevel, 0);
  assert.equal(store.state.incidents[0].status, 'ouvert');
  assert.equal(store.state.savings.length, 1);
});

test('données corrompues : retombe sur la base initiale sans planter', () => {
  mem.set('cc_points', '{pas du json');
  mem.set('cc_incidents', '"texte"');
  store.load();
  assert.equal(store.state.points.length, 50);
  assert.deepEqual(store.state.incidents, []);
});

test('esc neutralise le HTML ; CSV échappe les guillemets', () => {
  assert.equal(esc('<img src=x onerror="a()">&\''), '&lt;img src=x onerror=&quot;a()&quot;&gt;&amp;&#39;');
  assert.equal(esc(null), '');
  assert.equal(toCsv([['a"b', 'c;d']]), '\uFEFF"a""b";"c;d"');
});
