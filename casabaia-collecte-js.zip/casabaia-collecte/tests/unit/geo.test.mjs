import test from 'node:test';
import assert from 'node:assert/strict';
import { haversine, nearestNeighbor, routeKm, planTour, estimateMinutes } from '../../src/services/geo.js';
import { SEED_POINTS } from '../../src/database/seed.js';
import { DEPOT } from '../../src/js/config.js';

// Copie fidèle de l'algorithme de l'application d'origine (bundle index-PhwbVMyo.js, fonctions L/U)
function originalL(t, e) {
  const r = 6371e3, o = Math.PI / 180, a = (e.lat - t.lat) * o, l = (e.lng - t.lng) * o;
  const p = Math.sin(a / 2) ** 2 + Math.cos(t.lat * o) * Math.cos(e.lat * o) * Math.sin(l / 2) ** 2;
  return 2 * r * Math.asin(Math.sqrt(p));
}
function originalU(t) {
  const e = [...t], r = [];
  let o = { lat: 33.5985, lng: -7.586 };
  for (; e.length; ) {
    e.sort((a, l) => originalL(o, a) - originalL(o, l));
    o = e.shift();
    r.push(o);
  }
  return r;
}
function originalKm(order) {
  let v = 0, C = { lat: 33.5985, lng: -7.586 };
  order.forEach((h) => { v += originalL(C, h); C = h; });
  v += originalL(C, { lat: 33.5985, lng: -7.586 });
  return v * 1.3 / 1e3;
}

test('haversine : ~111 km par degré de latitude, 0 pour un même point', () => {
  assert.equal(haversine(DEPOT, DEPOT), 0);
  const d = haversine({ lat: 0, lng: 0 }, { lat: 1, lng: 0 });
  assert.ok(Math.abs(d - 111195) < 200, `d=${d}`);
});

test('optimisation identique à l’original sur tous les secteurs', () => {
  for (const sector of [null, 'Hay Adil', 'Belvédère', 'Roches Noires', 'Aïn Borja']) {
    const sel = SEED_POINTS.filter((p) => !sector || p.neighborhood === sector);
    const mine = nearestNeighbor(sel).map((p) => p.id);
    const orig = originalU(sel).map((p) => p.id);
    assert.deepEqual(mine, orig, `ordre différent pour ${sector}`);
    assert.equal(planTour(sel).km, Number(originalKm(originalU(sel)).toFixed(1)));
  }
});

test('nearestNeighbor ne modifie pas le tableau source et visite chaque point une fois', () => {
  const sel = SEED_POINTS.slice(0, 20);
  const copy = sel.map((p) => p.id);
  const order = nearestNeighbor(sel);
  assert.deepEqual(sel.map((p) => p.id), copy);
  assert.equal(new Set(order.map((p) => p.id)).size, 20);
});

test('planTour : économie ≥ 0, durée = km/25 km/h + 3 min par point', () => {
  const sel = SEED_POINTS.filter((p) => p.neighborhood === 'Belvédère');
  const plan = planTour(sel);
  assert.ok(plan.savedKm >= 0);
  assert.ok(plan.km <= plan.baselineKm + 0.05, 'le circuit optimisé ne doit pas être plus long que l’ordre de la liste');
  assert.equal(estimateMinutes(26, 10), Math.round((26 / 25) * 60 + 30));
});

test('cas limites : sélection vide, un seul point', () => {
  assert.deepEqual(nearestNeighbor([]), []);
  assert.equal(routeKm([]), 0);
  const one = planTour([SEED_POINTS[0]]);
  assert.equal(one.order.length, 1);
  assert.equal(one.savedKm, 0);
});
