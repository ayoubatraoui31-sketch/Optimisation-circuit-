import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, writeFile, readFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const script = fileURLToPath(new URL('../../scripts/patch-android.mjs', import.meta.url));
const sample = `<?xml version="1.0" encoding="utf-8" ?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <application android:label="@string/app_name"></application>
    <uses-permission android:name="android.permission.INTERNET" />
</manifest>
`;

test('patch-android ajoute les permissions une seule fois (idempotent)', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'cc-'));
  const f = join(dir, 'AndroidManifest.xml');
  await writeFile(f, sample);
  execFileSync('node', [script, f]);
  const once = await readFile(f, 'utf8');
  for (const p of ['ACCESS_FINE_LOCATION', 'ACCESS_COARSE_LOCATION', 'CAMERA']) assert.ok(once.includes(p), p);
  assert.ok(once.includes('android.permission.INTERNET'));
  execFileSync('node', [script, f]);
  assert.equal(await readFile(f, 'utf8'), once);
});
