#!/usr/bin/env node
/**
 * Tests de bout en bout (Chromium via Playwright) : `npm run build && npm run test:e2e`
 * Prérequis : npm install && npx playwright install chromium
 */
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { mkdir, readFile } from 'node:fs/promises';
import { createServer } from '../../scripts/serve.mjs';

const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const SHOTS = process.env.SHOTS_DIR; // optionnel : dossier de captures d'écran
if (SHOTS) await mkdir(SHOTS, { recursive: true });

const server = createServer();
await new Promise((r) => server.listen(0, r));
const base = `http://localhost:${server.address().port}/`;

const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
const PAGES = [
  ['dashboard', 'Tableau de bord'],
  ['points', 'Points de collecte'],
  ['tour', 'Tournée du jour'],
  ['incidents', 'Constats & incidents'],
  ['savings', 'Économies'],
  ['report', 'Rapports opérationnels'],
];

let passed = 0;
const failures = [];
async function check(name, fn) {
  try {
    await fn();
    passed++;
    console.log('  ✔', name);
  } catch (err) {
    failures.push(name);
    console.log('  ✘', name, '\n     ', process.env.DEBUG ? String(err.stack || err.message).split('\n').slice(0, 6).join('\n      ') : String(err.message).split('\n').find((l) => l.trim()) || String(err));
  }
}
const eq = (a, b, msg = '') => { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error(`${msg} attendu ${JSON.stringify(b)}, obtenu ${JSON.stringify(a)}`); };
const ok = (c, msg) => { if (!c) throw new Error(msg); };

const browser = await chromium.launch();

async function newPage({ mobile = false, offline = false } = {}) {
  const context = await browser.newContext({
    viewport: mobile ? { width: 390, height: 844 } : { width: 1280, height: 800 },
    hasTouch: mobile, isMobile: mobile, acceptDownloads: true,
    permissions: ['geolocation'], geolocation: { latitude: 33.5951, longitude: -7.5712 },
    serviceWorkers: 'allow',
  });
  const page = await context.newPage();
  page.setDefaultTimeout(6000);
  page.errors = [];
  page.on('pageerror', (e) => page.errors.push('pageerror: ' + e.message));
  page.on('console', (m) => m.type() === 'error' && !/openstreetmap|ERR_(INTERNET|NAME|CONNECTION|BLOCKED|FAILED)|Failed to load resource/i.test(m.text()) && page.errors.push('console: ' + m.text()));
  // Pas d'Internet dans ce test : la carte OpenStreetMap est simulée
  await page.route(/openstreetmap\.org/, (r) => r.fulfill({ status: 200, contentType: 'text/html', body: '<p>carte</p>' }));
  return page;
}
const TITLES = Object.fromEntries(PAGES);
/** Attend que la page `id` soit affichée (hashchange est asynchrone). */
const at = (page, id) => page.waitForFunction((t) => document.querySelector('#app h1')?.textContent === t, TITLES[id]);
const go = async (page, id) => { await page.evaluate((i) => (location.hash = i), id); await at(page, id); };
const h1 = (page) => page.locator('#app h1').innerText();
const statValues = (page) => page.locator('.stat-value').allInnerTexts();
const snap = (page, name) => SHOTS && page.screenshot({ path: `${SHOTS}/${name}.png`, fullPage: false });

/* ============ 1. Bureau : pages, navigation, données ============ */
console.log('\nBureau (1280×800)');
let page = await newPage();
await page.goto(base);
await page.waitForSelector('#app h1');

await check('le tableau de bord se charge sans erreur JS', async () => {
  eq(await h1(page), 'Tableau de bord');
  eq(await statValues(page), ['50', '0', '4', '0']);
  eq(await page.title(), 'Tableau de bord · Casabaia Collecte');
});
await snap(page, 'desktop-dashboard');

await check('les 6 pages de la barre latérale s’affichent', async () => {
  for (const [id, title] of PAGES) {
    await page.click(`.sidebar [data-page="${id}"]`);
    await at(page, id);
    ok(await page.locator(`.sidebar [data-page="${id}"].active`).count() === 1, 'menu actif ' + id);
  }
});

await check('le bouton Retour revient à la page précédente (historique par hash)', async () => {
  await page.click('.sidebar [data-page="points"]');
  await at(page, 'points');
  await page.click('.sidebar [data-page="tour"]');
  await at(page, 'tour');
  await page.goBack();
  await at(page, 'points');
});

await check('accès rapides et cartes de secteur du tableau de bord', async () => {
  await page.click('.sidebar [data-page="dashboard"]');
  await page.click('[data-go="tour"]'); await at(page, 'tour');
  await page.click('.sidebar [data-page="dashboard"]'); await at(page, 'dashboard');
  await page.click('[data-go="incidents"]'); await at(page, 'incidents');
  await page.click('.sidebar [data-page="dashboard"]'); await at(page, 'dashboard');
  await page.click('[data-go="points"]'); await at(page, 'points');
  await page.click('.sidebar [data-page="dashboard"]'); await at(page, 'dashboard');
  await page.click('[data-sector="Hay Adil"]');
  await at(page, 'points');
  eq(await page.locator('#sectorFilter').inputValue(), 'Hay Adil');
  eq(await page.locator('tbody tr').count(), 11);
});

/* ---- Points ---- */
await check('points : filtre par secteur et recherche', async () => {
  await page.selectOption('#sectorFilter', 'Tous');
  eq(await page.locator('tbody tr').count(), 50);
  await page.selectOption('#sectorFilter', 'Belvédère');
  eq(await page.locator('tbody tr').count(), 14);
  await page.selectOption('#sectorFilter', 'Al Bayda');
  ok((await page.locator('tbody').innerText()).includes('Aucun point trouvé'), 'état vide');
  await page.selectOption('#sectorFilter', 'Tous');
  await page.fill('#search', 'conteneur roches');
  eq(await page.locator('tbody tr').count(), 4); // p17, p20, p23, p26
  await page.fill('#search', 'p29');
  eq(await page.locator('tbody tr').count(), 1);
  await page.fill('#search', '');
});

await check('points : Collecté / Priorité / Ignorer / Réinitialiser + persistance', async () => {
  await page.fill('#search', 'p1');
  const row = page.locator('tbody tr', { hasText: 'Benne Belvédère 01' });
  await row.locator('[data-value="collected"]').click();
  ok((await page.locator('tbody tr', { hasText: 'Benne Belvédère 01' }).innerText()).includes('Collecté'));
  await page.locator('tbody tr', { hasText: 'Benne Belvédère 01' }).locator('[data-value="skipped"]').click();
  ok((await page.locator('tbody tr', { hasText: 'Benne Belvédère 01' }).innerText()).includes('Ignoré'));
  await page.locator('tbody tr', { hasText: 'Benne Belvédère 01' }).locator('[data-value="priority"]').click();
  ok((await page.locator('tbody tr', { hasText: 'Benne Belvédère 01' }).innerText()).includes('Prioritaire'));
  await page.locator('tbody tr', { hasText: 'Benne Belvédère 01' }).locator('[data-value="collected"]').click();
  await page.reload(); await page.waitForSelector('#app h1');
  await go(page, 'dashboard');
  eq(await statValues(page), ['50', '1', '4', '0']);
  ok((await page.locator('.stat-note').nth(1).innerText()).includes('2%'));
  await go(page, 'points'); await page.fill('#search', 'Benne Belvédère 01');
  await page.locator('[data-value="toCollect"]').first().click();
  await page.fill('#search', '');
  await go(page, 'dashboard');
  eq((await statValues(page))[1], '0');
});

await check('points : ajout (validation + succès), modification, suppression', async () => {
  await go(page, 'points');
  await page.click('#addPoint');
  await page.click('.modal [data-modal-action].primary');
  ok(await page.locator('#pointError').isVisible(), 'erreur nom vide');
  await page.fill('#pointForm [name=name]', 'Benne Test Al Bayda');
  await page.selectOption('#pointForm [name=neighborhood]', 'Al Bayda');
  await page.fill('#pointForm [name=lat]', '999');
  await page.click('.modal [data-modal-action].primary');
  ok((await page.locator('#pointError').innerText()).includes('invalides'), 'erreur GPS');
  await page.fill('#pointForm [name=lat]', '33.59');
  await page.fill('#pointForm [name=fillLevel]', '90');
  await page.click('.modal [data-modal-action].primary');
  await page.waitForSelector('.modal', { state: 'detached' });
  eq(await page.locator('#sectorFilter').inputValue(), 'Al Bayda', 'filtre positionné sur le secteur du nouveau point');
  await page.selectOption('#sectorFilter', 'Al Bayda');
  eq(await page.locator('tbody tr').count(), 1);
  ok((await page.locator('tbody').innerText()).includes('90%'));
  await go(page, 'dashboard');
  eq((await statValues(page))[0], '51'); eq((await statValues(page))[2], '5');
  await go(page, 'points'); await page.selectOption('#sectorFilter', 'Al Bayda');
  await page.click('[data-edit]');
  await page.fill('#pointForm [name=name]', 'Benne Test Renommée');
  await page.click('.modal [data-modal-action].primary');
  ok((await page.locator('tbody').innerText()).includes('Benne Test Renommée'));
  await page.click('[data-edit]');
  await page.click('.modal .danger');
  await page.click('.modal .primary'); // confirmer
  await page.waitForSelector('.modal', { state: 'detached' });
  ok((await page.locator('tbody').innerText()).includes('Aucun point'));
  await page.selectOption('#sectorFilter', 'Tous');
});

await check('sécurité : le HTML saisi est échappé (pas d’injection)', async () => {
  await page.click('#addPoint');
  await page.fill('#pointForm [name=name]', '<img src=x onerror="window.__xss=1">');
  await page.click('.modal [data-modal-action].primary');
  await page.waitForSelector('.modal', { state: 'detached' });
  await page.fill('#search', 'onerror');
  ok(await page.evaluate(() => window.__xss === undefined), 'script exécuté !');
  ok((await page.locator('tbody').innerText()).includes('<img src=x'), 'texte non affiché tel quel');
  await page.click('[data-edit]'); await page.click('.modal .danger'); await page.click('.modal .primary');
  await page.waitForSelector('.modal', { state: 'detached' });
  await page.fill('#search', '');
});

/* ---- Tournée & économies ---- */
await check('tournée : optimisation de tous les secteurs, distance/temps, économies', async () => {
  await go(page, 'tour');
  eq(await statValues(page), ['50', '0', '—', '—']);
  await page.click('#optimize');
  eq(await page.locator('.tour-list li').count(), 50);
  const v = await statValues(page);
  eq(v[1], '50');
  ok(/^\d+(\.\d)? km$/.test(v[2]) && /^\d+ min$/.test(v[3]), `valeurs ${v}`);
  ok(await page.locator('.tour-list a.maplink').first().getAttribute('href').then((h) => h.includes('openstreetmap.org/?mlat=')));
  await go(page, 'savings');
  const sv = await statValues(page);
  eq(sv[3], '1');
  ok(parseFloat(sv[0]) >= 0, 'km économisés');
});

await check('tournée : optimisation par secteur + points collectés exclus', async () => {
  await go(page, 'points'); await page.selectOption('#sectorFilter', 'Tous'); await page.fill('#search', 'p29');
  await page.locator('[data-value="collected"]').first().click();
  await page.fill('#search', '');
  await go(page, 'tour');
  eq((await statValues(page))[0], '49');
  await page.selectOption('#tourSector', 'Hay Adil');
  await page.click('#optimize');
  eq(await page.locator('.tour-list li').count(), 10);
  eq(await page.locator('#tourSector').inputValue(), 'Hay Adil', 'sélection conservée');
  await go(page, 'savings');
  eq((await statValues(page))[3], '2');
  ok((await page.locator('.saving-row').first().innerText()).includes('Hay Adil'));
});

await check('tournée : réinitialiser la sélection', async () => {
  await go(page, 'tour');
  await page.click('#resetTour');
  eq(await page.locator('.tour-list li').count(), 0);
  eq((await statValues(page)).slice(2), ['—', '—']);
  await go(page, 'points'); await page.selectOption('#sectorFilter', 'Tous'); await page.fill('#search', 'p29');
  await page.locator('[data-value="toCollect"]').first().click();
  await page.fill('#search', '');
});

/* ---- Constats ---- */
await check('constats : validation, photo, GPS, enregistrement, visualisation, clôture', async () => {
  await go(page, 'incidents');
  await page.click('#incidentForm button[type=submit]');
  ok(await page.locator('.toast.error').count() >= 1 || await page.evaluate(() => !document.querySelector('#incidentForm textarea').checkValidity()), 'description obligatoire');
  await page.selectOption('#incidentForm [name=sector]', 'Roches Noires');
  await page.selectOption('#incidentForm [name=type]', 'Dépôt sauvage');
  await page.fill('#incidentForm [name=description]', 'Gravats devant le point 03 <b>test</b>');
  const [chooser] = await Promise.all([page.waitForEvent('filechooser'), page.click('#photoBtn')]);
  await chooser.setFiles({ name: 'photo.png', mimeType: 'image/png', buffer: PNG });
  await page.waitForSelector('#photoPreview:not(.hidden)');
  await page.click('#gps');
  await page.waitForFunction(() => document.querySelector('#gpsText').textContent.startsWith('GPS récupéré'));
  eq(await page.locator('#incidentForm [name=lat]').inputValue(), '33.5951');
  await page.click('#incidentForm button[type=submit]');
  await page.waitForSelector('#history tbody tr');
  const row = page.locator('#history tbody tr').first();
  const txt = await row.innerText();
  ok(txt.includes('Roches Noires') && txt.includes('Dépôt sauvage') && txt.includes('ouvert') && txt.includes('GPS 33.59510'), txt);
  ok(txt.includes('<b>test</b>'), 'description échappée');
  await row.locator('[data-photo]').click();
  await page.waitForSelector('.modal img.photo-full');
  ok(await page.evaluate(() => document.querySelector('.photo-full').src.startsWith('data:image/jpeg')), 'photo compressée en JPEG');
  await page.keyboard.press('Escape');
  await page.waitForSelector('.modal', { state: 'detached' });
  await go(page, 'dashboard');
  eq((await statValues(page))[3], '1');
  await go(page, 'incidents');
  await page.click('[data-close]');
  ok((await page.locator('#history tbody tr').first().innerText()).includes('clôturé'));
  eq(await page.locator('[data-close]').count(), 0, 'plus de bouton Clôturer');
  await go(page, 'dashboard');
  eq((await statValues(page))[3], '0');
});
await go(page, 'incidents'); await snap(page, 'desktop-incidents');

await check('constats : la photo est stockée dans IndexedDB, pas dans localStorage', async () => {
  const r = await page.evaluate(async () => {
    const inc = JSON.parse(localStorage.getItem('cc_incidents'))[0];
    const db = await new Promise((res) => { const q = indexedDB.open('casabaia-collecte'); q.onsuccess = () => res(q.result); });
    const val = await new Promise((res) => { const q = db.transaction('photos').objectStore('photos').get(inc.photoId); q.onsuccess = () => res(q.result); });
    return { hasInline: 'photo' in inc, photoId: inc.photoId, stored: typeof val === 'string' && val.startsWith('data:') };
  });
  eq(r.hasInline, false); ok(r.photoId, 'photoId'); ok(r.stored, 'photo en base');
});

/* ---- Rapports ---- */
let backupPath;
await check('rapports : export JSON / CSV / résumé', async () => {
  await go(page, 'report');
  eq((await statValues(page)).length, 4);
  let [dl] = await Promise.all([page.waitForEvent('download'), page.click('#exportJson')]);
  eq(dl.suggestedFilename(), 'casabaia-sauvegarde.json');
  backupPath = await dl.path();
  const data = JSON.parse(await readFile(backupPath, 'utf8'));
  eq(data.points.length, 50); eq(data.incidents.length, 1);
  ok(data.incidents[0].photo?.startsWith('data:image'), 'photo incluse dans la sauvegarde');
  eq(data.incidents[0].photoId, undefined);
  [dl] = await Promise.all([page.waitForEvent('download'), page.click('#exportCsv')]);
  eq(dl.suggestedFilename(), 'casabaia-points.csv');
  const csv = await readFile(await dl.path(), 'utf8');
  ok(csv.startsWith('\uFEFF"ID";"Nom"'), 'BOM + en-têtes'); eq(csv.trim().split('\n').length, 51);
  [dl] = await Promise.all([page.waitForEvent('download'), page.click('#shareReport')]);
  eq(dl.suggestedFilename(), 'rapport-casabaia.txt');
  ok((await readFile(await dl.path(), 'utf8')).includes('Points: 50'));
});

await check('rapports : import (confirmation, restauration, fichiers invalides)', async () => {
  await go(page, 'points'); await page.selectOption('#sectorFilter', 'Tous'); await page.fill('#search', 'Benne Belvédère 02');
  await page.locator('tbody tr', { hasText: 'Benne Belvédère 02' }).locator('[data-value="priority"]').click();
  await page.fill('#search', '');
  await go(page, 'report');
  await page.setInputFiles('#importJson', backupPath);
  await page.waitForSelector('.modal');
  await page.click('.modal .secondary'); // Annuler
  await page.waitForSelector('.modal', { state: 'detached' });
  await page.setInputFiles('#importJson', { name: 'x.json', mimeType: 'application/json', buffer: Buffer.from('pas du json') });
  await page.waitForSelector('.toast.error');
  await page.setInputFiles('#importJson', backupPath);
  await page.click('.modal .primary');
  await page.waitForSelector('.toast:has-text("Sauvegarde importée")');
  await go(page, 'incidents');
  eq(await page.locator('#history tbody tr').count(), 1);
  ok(await page.locator('[data-photo]').count() === 1, 'photo restaurée après import');
});

await check('persistance : tout est conservé après rechargement', async () => {
  await page.reload(); await at(page, 'incidents');
  eq(await page.locator('#history tbody tr').count(), 1);
  await page.locator('[data-photo]').click();
  await page.waitForSelector('.modal img.photo-full');
  await page.keyboard.press('Escape');
});

await check('aucune erreur JavaScript pendant toute la session bureau', async () => eq(page.errors, []));
await page.context().close();

/* ============ 2. Mobile ============ */
console.log('\nMobile (390×844, tactile)');
page = await newPage({ mobile: true });
await page.goto(base); await page.waitForSelector('#app h1');

await check('mobile : barre latérale masquée, navigation basse à 6 entrées', async () => {
  ok(!(await page.locator('.sidebar').isVisible()), 'sidebar visible');
  ok(await page.locator('.mobile-nav').isVisible(), 'mobile-nav cachée');
  eq(await page.locator('.mobile-nav button').count(), 6);
});
await check('mobile : chaque page s’ouvre, sans débordement horizontal, nav toujours visible', async () => {
  for (const [id, title] of PAGES) {
    await page.tap(`.mobile-nav [data-page="${id}"]`);
    await at(page, id);
    const m = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, iw: innerWidth }));
    ok(m.sw <= m.iw, `${id}: débordement ${m.sw} > ${m.iw}`);
    const nav = await page.locator('.mobile-nav').boundingBox();
    ok(Math.round(nav.y + nav.height) === 844, `${id}: nav hors écran`);
    await snap(page, `mobile-${id}`);
  }
});
await check('mobile : le tableau des points devient une liste de cartes utilisable', async () => {
  await page.tap('.mobile-nav [data-page="points"]');
  await at(page, 'points');
  ok(!(await page.locator('thead').isVisible()), 'en-têtes de tableau visibles');
  const tdWidth = await page.locator('tbody tr').first().evaluate((el) => el.getBoundingClientRect().width);
  ok(tdWidth <= 390, 'ligne trop large');
  await page.locator('tbody tr').first().locator('[data-value="collected"]').tap();
  ok((await page.locator('tbody tr').first().innerText()).includes('Collecté'));
});
await check('mobile : boutons tactiles ≥ 34 px de haut', async () => {
  const small = await page.evaluate(() => [...document.querySelectorAll('button, select, input.input')].filter((e) => e.offsetParent && e.getBoundingClientRect().height < 34).map((e) => e.className || e.id));
  eq(small, []);
});
await check('mobile : formulaire de constat en une colonne', async () => {
  await page.tap('.mobile-nav [data-page="incidents"]');
  await at(page, 'incidents');
  const cols = await page.evaluate(() => getComputedStyle(document.querySelector('#incidentForm')).gridTemplateColumns.split(' ').length);
  eq(cols, 1);
});
await check('aucune erreur JavaScript pendant la session mobile', async () => eq(page.errors, []));
await page.context().close();

/* ============ 3. Hors ligne, anciennes données ============ */
console.log('\nHors ligne & migration');
page = await newPage();
await page.goto(base); await page.waitForSelector('#app h1');
await check('service worker : installé, application disponible hors ligne', async () => {
  await page.evaluate(() => navigator.serviceWorker.ready);
  await page.reload(); await page.waitForSelector('#app h1');
  ok(await page.evaluate(() => !!navigator.serviceWorker.controller), 'pas de contrôle SW');
  await page.context().setOffline(true);
  await page.reload(); await page.waitForSelector('#app h1');
  eq(await h1(page), 'Tableau de bord');
  await go(page, 'points'); eq(await page.locator('tbody tr').count(), 50);
  await page.context().setOffline(false);
});
await check('migration : anciennes données (clés cc_*, photo en base64) reprises', async () => {
  await page.evaluate((png) => {
    localStorage.setItem('cc_points', JSON.stringify([{ id: 'p1', name: 'Benne Ancienne', neighborhood: 'Hay Adil', address: 'x', lat: 33.58, lng: -7.55, status: 'collected', inTodayTour: true }]));
    localStorage.setItem('cc_incidents', JSON.stringify([{ id: 'INC-1', date: '2026-01-05T10:00:00.000Z', sector: 'Hay Adil', type: 'Obstacle', description: 'Ancien constat', photo: 'data:image/png;base64,' + png, lat: '', lng: '', status: 'ouvert' }]));
    localStorage.setItem('cc_savings', JSON.stringify([{ date: '2026-01-05', km: 0 }]));
  }, PNG.toString('base64'));
  await page.reload(); await page.waitForSelector('#app h1');
  await go(page, 'dashboard');
  eq(await statValues(page), ['1', '1', '0', '1']);
  await go(page, 'incidents');
  await page.waitForFunction(() => JSON.parse(localStorage.getItem('cc_incidents'))[0].photoId);
  await page.reload(); await page.waitForSelector('#history tbody tr');
  eq(await page.locator('[data-photo]').count(), 1);
  await go(page, 'savings');
  ok((await page.locator('.saving-row').innerText()).includes('0.0 km'));
});
await check('aucune erreur JavaScript (hors ligne / migration)', async () => eq(page.errors, []));
await check('stockage indisponible : message d’erreur, pas de plantage', async () => {
  await page.evaluate(() => { Storage.prototype.setItem = () => { throw new DOMException('quota', 'QuotaExceededError'); }; });
  await go(page, 'points');
  await page.locator('[data-value="priority"]').first().click();
  await page.waitForSelector('.toast.error:has-text("Stockage")');
});
await page.context().close();

/* ============ 4. Branches « natives » (faux window.Capacitor) ============ */
console.log('\nIntégration Capacitor simulée (ne teste pas les vrais plugins Android)');
page = await newPage();
await page.addInitScript((png) => {
  const calls = [];
  window.__calls = calls;
  window.Capacitor = {
    isNativePlatform: () => true,
    Plugins: {
      Geolocation: { requestPermissions: async () => ({ location: 'granted' }), getCurrentPosition: async (o) => (calls.push(['geo', o]), { coords: { latitude: 33.6, longitude: -7.58 } }) },
      Camera: { getPhoto: async (o) => (calls.push(['camera', o]), { dataUrl: 'data:image/png;base64,' + png }) },
      Filesystem: { writeFile: async (o) => (calls.push(['fs', o.path, o.directory, o.encoding, o.data.length]), { uri: 'file:///cache/' + o.path }) },
      Share: { share: async (o) => (calls.push(['share', o.title, o.url ?? null, o.text ?? null])) },
    },
  };
}, PNG.toString('base64'));
await page.goto(base); await page.waitForSelector('#app h1');
await check('natif : pas de bouton Installer ni de service worker', async () => {
  ok(await page.locator('#installBtn.hidden').count() === 1, 'bouton visible');
  await page.waitForTimeout(500);
  eq(await page.evaluate(async () => (await navigator.serviceWorker.getRegistrations()).length), 0);
});
await check('natif : GPS et caméra passent par les plugins Capacitor', async () => {
  await go(page, 'incidents');
  await page.click('#gps');
  await page.waitForFunction(() => document.querySelector('#gpsText').textContent.includes('33.60000'));
  await page.click('#photoBtn');
  await page.waitForSelector('#photoPreview:not(.hidden)');
  const calls = await page.evaluate(() => window.__calls);
  eq(calls.find((c) => c[0] === 'geo')[1].enableHighAccuracy, true);
  const cam = calls.find((c) => c[0] === 'camera')[1];
  eq([cam.resultType, cam.source], ['dataUrl', 'PROMPT']);
  await page.fill('#incidentForm [name=description]', 'test natif');
  await page.click('#incidentForm button[type=submit]');
  await page.waitForSelector('#history tbody tr');
});
await check('natif : export = écriture dans le cache + feuille de partage ; résumé partagé', async () => {
  await go(page, 'report');
  await page.click('#exportJson'); await page.waitForSelector('.toast:has-text("exportée")');
  await page.click('#exportCsv'); await page.waitForSelector('.toast:has-text("CSV")');
  await page.click('#shareReport');
  await page.waitForFunction(() => window.__calls.filter((c) => c[0] === 'share').length === 3);
  const calls = await page.evaluate(() => window.__calls);
  const fs = calls.filter((c) => c[0] === 'fs');
  eq(fs.map((c) => c[1]), ['casabaia-sauvegarde.json', 'casabaia-points.csv']);
  eq([fs[0][2], fs[0][3]], ['CACHE', 'utf8']);
  const sh = calls.filter((c) => c[0] === 'share');
  eq(sh[0][2], 'file:///cache/casabaia-sauvegarde.json');
  ok(sh[2][3].includes('Points: 50'), 'résumé');
});
await check('aucune erreur JavaScript (mode natif simulé)', async () => eq(page.errors, []));
await page.context().close();

await browser.close();
server.close();
console.log(`\n${passed} réussis, ${failures.length} échoués`);
if (failures.length) { console.log('Échecs :', failures.join(' | ')); process.exit(1); }
