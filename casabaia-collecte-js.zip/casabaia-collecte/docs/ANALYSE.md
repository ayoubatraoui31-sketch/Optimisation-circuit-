# Analyse du ZIP d'origine

## Contenu réel du ZIP

`Casabaia-Collecte-APK.zip` ne contient **qu'un seul fichier : `app-debug.apk`** (3,4 Mo, 491 entrées). Il n'y avait
**pas de code source** ; la reconstruction part donc de l'APK décompressé.

| Élément | Constat |
|---|---|
| Type d'application | Android **Capacitor** (`ma.casabaia.collecte`, nom « Casabaia Collecte », schéma `https`) |
| Code applicatif | `assets/public/assets/index-*.js` : un bundle **Vite minifié de 22 Ko**, JavaScript natif sans framework, lu et analysé intégralement |
| HTML / CSS | `assets/public/index.html` et `index-*.css` (5 Ko), repris fidèlement (identité verte `#0c5b45`, mise en page, libellés) |
| Plugins natifs | `capacitor.plugins.json` = `[]` : **aucun plugin** ; seule permission : `INTERNET` |
| Code natif | `classes3/4.dex` : coque Capacitor standard + AndroidX/Kotlin. Non décompilés (pas d'outil disponible) ; rien n'indique de code natif sur mesure |
| Icône / splash | Ressources **par défaut de Capacitor** (pas d'identité visuelle propre) → remplacées par un « C » vert à l'identité de l'app |
| Service worker | Enregistré (`./sw.js`) mais **absent de l'APK** : l'enregistrement échouait silencieusement |
| Stockage | `localStorage` : `cc_points`, `cc_incidents`, `cc_savings`, `cc_session` |

## Fonctionnalités de l'original (toutes conservées)

- **Données** : 50 points (14 Belvédère, 14 Roches Noires, 11 Hay Adil, 11 Aïn Borja ; « Al Bayda » est un secteur sans point), 4 prioritaires.
- **Tableau de bord** : 4 indicateurs, suivi par secteur cliquable, accès rapides.
- **Points** : recherche, filtre par secteur, boutons Collecté / Priorité / Réinitialiser, ajout.
- **Tournée** : plus proche voisin depuis (33.5985, −7.586), distance ×1,3, 25 km/h + 3 min/point, carte OSM intégrée, réinitialisation.
- **Constats** : 7 types, description, photo, GPS, historique, clôture.
- **Économies** : cumul km, 10 km/L, 13 MAD/L.
- **Rapports** : export JSON/CSV (séparateur `;`, BOM), partage, import JSON, installation PWA.

Les formules et constantes sont reprises à l'identique ; un test unitaire compare l'optimiseur au code d'origine sur tous les secteurs.

## Défauts de l'original corrigés

| Constat dans l'original | Correction |
|---|---|
| La page **Économies** ne comptait **jamais** de km (`km: 0` enregistré à chaque optimisation) | Économie = km de l'ordre de la liste − km de l'ordre optimisé ; une entrée par jour et secteur |
| **Économies inaccessible sur mobile** (absente de la barre basse, barre latérale masquée) | 6 entrées dans la navigation mobile |
| Statut « Ignoré » affiché mais **impossible à définir** | Bouton « Ignorer » |
| `fillLevel` / `priorityLevel` utilisés dans les calculs mais **jamais modifiables** | Champ « Remplissage » dans le formulaire de point (≥ 80 % ⇒ prioritaire) |
| Ajout d'un point par **5 boîtes `prompt()`** | Formulaire modal validé (coordonnées contrôlées) |
| Photos en base64 dans localStorage (~5 Mo max) puis **jamais affichées** | IndexedDB + compression 1280 px ; bouton « Photo » dans l'historique |
| **Export impossible sur Android** (téléchargement `blob:` non géré par la WebView) | Filesystem + feuille de partage natives |
| Bouton « Clôturer » toujours affiché | Masqué une fois clôturé ; historique du plus récent au plus ancien |
| Service worker absent | `sw.js` réel (hors ligne) |
| Pages courtes **centrées verticalement** (`margin:auto` dans un conteneur flex) | Corrigé |
| Navigation sans historique | Routage par `#hash` : bouton Retour d'Android fonctionnel |
| Import JSON sans confirmation | Confirmation avant remplacement |
| Tableaux à défilement horizontal sur mobile | Cartes empilées |

## Ajouts mineurs (hors objectif initial : aucun)

Modification et suppression d'un point (nécessaires pour exploiter `fillLevel`), lien « Carte » par étape de tournée,
cadre de dialogue pour les confirmations. Aucune fonctionnalité nouvelle qui change la finalité de l'application.
