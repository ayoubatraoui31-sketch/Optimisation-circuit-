#!/usr/bin/env node
/**
 * À lancer après `npx cap add android` : ajoute au AndroidManifest.xml les permissions
 * nécessaires (GPS pour les constats, caméra pour les photos). Idempotent.
 */
import { readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';

const file = process.argv[2] || fileURLToPath(new URL('../android/app/src/main/AndroidManifest.xml', import.meta.url));
const wanted = [
  '<uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />',
  '<uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />',
  '<uses-permission android:name="android.permission.CAMERA" />',
  '<uses-feature android:name="android.hardware.location.gps" android:required="false" />',
  '<uses-feature android:name="android.hardware.camera" android:required="false" />',
];

let xml;
try {
  xml = await readFile(file, 'utf8');
} catch {
  console.error(`✘ Manifest introuvable : ${file}\n  Lancez d'abord « npm run android:add ».`);
  process.exit(1);
}
const missing = wanted.filter((line) => !xml.includes(line.match(/android:name="([^"]+)"/)[1]));
if (!missing.length) {
  console.log('✔ Permissions déjà présentes.');
} else {
  if (!xml.includes('</manifest>')) {
    console.error('✘ Manifest invalide (balise </manifest> absente).');
    process.exit(1);
  }
  xml = xml.replace('</manifest>', missing.map((l) => '    ' + l).join('\n') + '\n</manifest>');
  await writeFile(file, xml);
  console.log(`✔ ${missing.length} déclaration(s) ajoutée(s) à ${file}`);
}
