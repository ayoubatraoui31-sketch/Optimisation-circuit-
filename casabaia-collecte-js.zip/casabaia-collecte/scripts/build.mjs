#!/usr/bin/env node
/**
 * Assemble l'application web dans ./www (dossier lu par Capacitor).
 * Aucune dépendance : copie des fichiers + génération de la liste de pré-cache du service worker.
 */
import { cp, rm, mkdir, readFile, writeFile, readdir } from 'node:fs/promises';
import { join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('..', import.meta.url));
const out = join(root, 'www');
const pkg = JSON.parse(await readFile(join(root, 'package.json'), 'utf8'));

await rm(out, { recursive: true, force: true });
await mkdir(out, { recursive: true });
for (const entry of ['index.html', 'manifest.webmanifest', 'src', 'assets/icons', 'assets/images']) {
  await cp(join(root, entry), join(out, entry), { recursive: true });
}

async function walk(dir) {
  const files = [];
  for (const e of await readdir(dir, { withFileTypes: true })) {
    const p = join(dir, e.name);
    if (e.isDirectory()) files.push(...(await walk(p)));
    else files.push(p);
  }
  return files;
}
const precache = (await walk(out)).map((f) => './' + relative(out, f).replaceAll('\\', '/'));
precache.push('./');

const sw = (await readFile(join(root, 'sw.js'), 'utf8'))
  .replace('__VERSION__', pkg.version)
  .replace('self.__PRECACHE__ || []', JSON.stringify(precache));
await writeFile(join(out, 'sw.js'), sw);

console.log(`✔ www/ prêt (${precache.length} fichiers, version ${pkg.version})`);
