# Casabaia Collecte — version JavaScript

Application de gestion des **tournées et points de collecte** (Casablanca) : suivi des bennes et conteneurs,
optimisation du circuit du jour, constats terrain avec photo et GPS, économies de trajet, sauvegardes et rapports.

Reconstruction en **JavaScript / HTML5 / CSS3 pur** (aucun framework, aucune dépendance à l'exécution) de l'application
Android d'origine `ma.casabaia.collecte` (« Casabaia Collecte V3.4 JS »). Fonctionne dans un navigateur, en PWA hors
ligne, et se transforme en **APK Android avec Capacitor**. Détail de l'analyse : [`docs/ANALYSE.md`](docs/ANALYSE.md).

## Fonctionnalités

| Page | Contenu |
|---|---|
| **Tableau de bord** | 4 indicateurs (points, collectés, prioritaires, constats ouverts), avancement par secteur (cliquable), accès rapides |
| **Points de collecte** | 50 points d'origine, recherche, filtre par secteur, états *Collecté / Prioritaire / Ignoré / À collecter*, ajout et modification d'un point |
| **Tournée du jour** | Optimisation « plus proche voisin » depuis le dépôt, distance (×1,3 routier) et temps (25 km/h + 3 min/point), carte OpenStreetMap |
| **Constats & incidents** | Secteur, type, description, **photo** (caméra), **position GPS**, historique, clôture |
| **Économies** | Km économisés par optimisation, équivalent carburant (10 km/L) et financier (13 MAD/L) |
| **Rapports** | Export sauvegarde JSON, export CSV des points, partage du résumé, import d'une sauvegarde |

Les données restent **sur l'appareil** (localStorage + IndexedDB pour les photos) : aucun serveur, aucun compte.

## Démarrage rapide (navigateur)

Prérequis : [Node.js](https://nodejs.org) 20 ou plus. Aucune installation de paquet n'est nécessaire pour lancer l'application.

```bash
npm start          # assemble www/ puis sert http://localhost:5173
```

> Ouvrir `index.html` directement (`file://`) ne fonctionne pas : les modules JavaScript exigent un serveur HTTP.
> Hébergeable tel quel sur n'importe quel hébergement statique (copier le contenu de `www/`).

## Structure

```
index.html                 point d'entrée
manifest.webmanifest, sw.js   PWA + hors ligne (sw.js est complété par le build)
capacitor.config.json      appId ma.casabaia.collecte, webDir = www
src/
  js/        main.js (routeur par #hash), config.js (constantes métier), ui-state.js
  pages/     dashboard, points, tour, incidents, savings, report
  components/ ui.js (cartes, badges, toasts), modal.js
  services/  geo.js (haversine, optimisation, GPS), camera.js, files.js, platform.js, format.js
  database/  store.js (état + persistance), storage.js (localStorage), photos.js (IndexedDB), seed.js (50 points)
  css/       base.css, layout.css, components.css
assets/      icons/ (PWA), images/, + sources icône/splash Android (icon-*.png, splash*.png)
scripts/     build.mjs, serve.mjs, patch-android.mjs
tests/       unit/ (node:test) et e2e/ (Playwright)
docs/        ANALYSE.md
```

## Tests

```bash
npm test                                   # 18 tests unitaires, sans dépendance
npm install && npx playwright install chromium
npm run build && npm run test:e2e          # 31 contrôles dans un vrai Chromium (bureau, mobile, hors ligne)
```

## Générer l'APK Android

Prérequis : Node.js 20+, **JDK 21**, **Android Studio** (avec Android SDK ; `ANDROID_HOME` défini).
Le projet cible **Capacitor 7** ; pour une version plus récente, mettez à jour ensemble tous les paquets `@capacitor/*` de `package.json`.

```bash
npm install                 # installe Capacitor et ses plugins (réseau requis)
npm run android:add         # crée le dossier android/ + ajoute les permissions GPS/caméra
npm run assets              # génère icônes et écran de démarrage depuis assets/*.png
npm run android:sync        # build web + copie dans android/
```

Puis, au choix :

**A. Ligne de commande (APK de test, signé avec la clé debug)**
```bash
cd android
./gradlew assembleDebug            # Windows : gradlew.bat assembleDebug
# → android/app/build/outputs/apk/debug/app-debug.apk
adb install -r app/build/outputs/apk/debug/app-debug.apk    # ou copier l'APK sur le téléphone
```

**B. Android Studio** : `npm run android:open`, puis *Build ▸ Build Bundle(s) / APK(s) ▸ Build APK(s)*.

**APK de distribution** : *Build ▸ Generate Signed Bundle / APK ▸ APK*, créez un keystore (à **sauvegarder** : sans lui,
impossible de publier des mises à jour) puis choisissez la variante `release`.

Après chaque modification du code web : `npm run android:sync`, puis recompilez.

### Remplacer l'ancienne application sans perdre les données

Les données de l'ancienne app (`cc_points`, `cc_incidents`, `cc_savings`, `cc_session`) sont **reprises automatiquement**
(mêmes clés, mêmes formats, photos migrées vers IndexedDB) **si** le nouvel APK s'installe *par-dessus* l'ancien. Android
l'exige : même `appId` (`ma.casabaia.collecte`, déjà le cas) **et même clé de signature**. Si l'installation est refusée
(« conflit de paquet »), il faut désinstaller l'ancienne app, ce qui **efface ses données** : exportez d'abord une
sauvegarde JSON depuis l'ancienne app (page *Rapports*), puis importez-la dans la nouvelle.

## Fonctions natives Android

| Besoin | Plugin | Repli navigateur |
|---|---|---|
| Position GPS | `@capacitor/geolocation` | `navigator.geolocation` |
| Photo | `@capacitor/camera` | `<input type="file" capture>` |
| Export de fichiers | `@capacitor/filesystem` + `@capacitor/share` | téléchargement classique |
| Partage du résumé | `@capacitor/share` | `navigator.share` ou fichier texte |

`npm run android:add` déclare les permissions `ACCESS_FINE_LOCATION`, `ACCESS_COARSE_LOCATION` et `CAMERA`
(`scripts/patch-android.mjs`). La carte OpenStreetMap et les tuiles nécessitent Internet ; le reste fonctionne hors ligne.

## Limites connues

- Distances **estimées** à vol d'oiseau ×1,3 (pas d'itinéraire routier) ; l'« économie » compare l'ordre optimisé à l'ordre de la liste.
- Pas de synchronisation entre appareils (comme l'original) : utilisez les sauvegardes JSON.
- `localStorage` est limité à ~5 Mo dans une WebView : les photos sont donc stockées à part (IndexedDB) et réduites à 1280 px.
